#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <inttypes.h>
#include <e-hal.h> // HOST side ; mandatory

#include "C_common.h"  // common definitions for C

#define MY_EPIPHANY_ELF "bin/e_e2h.elf"
#define BENCH_MIN 0    //min bench to start with
#define BENCH_MAX 1024 //max bench to start with
#define BENCH_LIMIT 10000 //stop after x benchs done ; not implemented actually
#include "common.h"    // common definitions for your project

//#######################################

void Epiphany_Boot(e_platform_t *epiphany) {
  e_init(NULL); // initialise the system, establish connection to the device
  e_reset_system(); // reset the Epiphany chip
  e_get_platform_info(epiphany);// get the configuration info for the parallella platform
}

//#######################################

void usage(void) {
  printf("Usage: [timer_event0] [timer_event1] [...]\n");
  printf("  timer_event0: default 1  ; 1-13, list below\n");
  printf("  timer_event1: default 4  ; 1-13, list below\n\n");
  
  // doc from enum type e_ctimer_config_t
  printf("The supported ctimer events are:\n\n");
  printf("  E_CTIMER_CLK              =  1\n");
  printf("  E_CTIMER_IDLE             =  2\n");
  printf("  E_CTIMER_IALU_INST        =  4\n");
  printf("  E_CTIMER_FPU_INST         =  5\n");
  printf("  E_CTIMER_DUAL_INST        =  6\n");
  printf("  E_CTIMER_E1_STALLS        =  7\n");
  printf("  E_CTIMER_RA_STALLS        =  8\n");
  printf("  E_CTIMER_EXT_FETCH_STALLS = 12\n");
  printf("  E_CTIMER_EXT_LOAD_STALLS  = 13\n");
  printf("  E_CTIMER_64BIT            =  3 // Only on Epiphany-IV+\n\n");
  
}

//#######################################

int main(int argc, char *argv[]) {

  // Epiphany input/output through shared RAM ; details: common.h
  Sio     fromio;//Sio *fromio=(Sio *)malloc(sizeof(Sio));
  int row, col, timer0=1, timer1=4;
  e_platform_t epiphany;// Epiphany platform configuration
	e_epiphany_t dev;
  
  int64_t l1=0;
	int i, j, fn1, fn2;
  /* FILE *fin;
  int bench_start=BENCH_MIN;
  char *tbench=(char *)malloc(MAX_CORE_N * 17 * 16); */

	if(argc >= 3) {
		i=atoi(argv[1]); 
    if(i <= 13) timer0=i;
		i=atoi(argv[2]); 
    if(i <= 13) timer1=i;
    if(argc >= 4) {
      // add your commands, master !
    }
  }
  else {
    usage();
  }

  //get some data
  /*
  fin=fopen("./bin/bench.bin", "rb");
  ifz(fin) { printf("Error reading file bin/bench.bin ; did you generate it with build_data.sh ?\n"); exit(-1); }
  fseek(fin, 17 * bench_start, 0);
  i=fread(tbench, MAX_CORE_N * 17 * 16, 1, fin);
  fclose(fin);
  */
  
  pf("sz(io) = %u\n", sizeof(Sio));

  printf("\n\nCanvas for your MPMD project with configurable event timer stats :) \n\n\n");
	print("Don't forget to customize MY_EPIPHANY_ELF, that's useful for the 'e_load_group' line with YOUR Epiphany elf file !\n");
  
  Epiphany_Boot(&epiphany);

	// Create a workgroup using all of the cores	
	e_open(&dev, 0, 0, epiphany.rows, epiphany.cols);
	e_reset_group(&dev);
	// Load the device code into each core of the chip, and don't start it yet
	e_load_group(MY_EPIPHANY_ELF, &dev, 0, 0, epiphany.rows, epiphany.cols, E_FALSE);

	// Set the maximum per core test value on each core at address 0x7020
	i=0;
  for(row=0;row<epiphany.rows;row++) {
		for(col=0;col<epiphany.cols;col++) {
      // init input/output
      fromio.out.cmd=CMD_INIT;
      LOOP1(8) fromio.out.ttimer0[fn1]=0;
      LOOP1(8) fromio.out.ttimer1[fn1]=0;
      fromio.in.mastercore= (row==0) & (col==0);
      fromio.in.timer0=timer0;
      fromio.in.timer1=timer1;
      
			e_write(&dev, row, col, SHARED_IN, &fromio, sizeof(Sio));
      pf("i %u ; in written\n", i);

      i++;
		}
	}

	// Start all of the cores
  pf("Starting the core workgroup...\n\n");
	e_start_group(&dev);
  pf("... core workgroup started ; the whole test will last about ... seconds...\n\n");

	while(1) {
		usleep(100000);
    //pf("fromio.out.cmd: 0x%08X\n", fromio.out.cmd);
		int done = 0;

		// wait for the cores to complete their work
		i=0;
    for(row=0;row<epiphany.rows;row++) {
			for(col=0;col<epiphany.cols;col++) {
				// Get the number being tested by the core
				if(e_read(&dev, row, col, SHARED_CMD, &fromio.out.cmd, sizeof(uint)) != sizeof(uint))
					fprintf(stderr, "\n\nFailed to read\n\n\n");

				if ( fromio.out.cmd != CMD_INIT) { //== CMD_DONE) {
          if(e_read(&dev, row, col, SHARED_OUT, &fromio.out, sizeof(Soutput)) != sizeof(Soutput))
            fprintf(stderr, "\n\nFailed to read 2\n\n\n");
          pf("Timer 0: %9u\n", fromio.out.timer0);
          pf("Timer 1: %9u\n", fromio.out.timer1);
          LOOP1(8) pf("timer 0, raw init cost, try # %u: %u\n", fn1, fromio.out.ttimer0[fn1]); 
          LOOP1(8) pf("timer 1, raw init cost, try # %u: %u\n", fn1, fromio.out.ttimer1[fn1]); 
          
          pf("core %4u: cmd 0x%08X.\n", i, fromio.out.cmd);

/* if u need to reset a core, use this:
          fromio.out.cmd=CMD_INIT;
          // etc
          e_write(&dev, row, col, SHARED_IN, &fromio, sizeof(Sio));
pf("i %u ; in written again\n", i);
//OBSOLETE ! esdk doc too :/    e_reset_core(&dev, row, col); u must use e_start(&dev, row, col) instead
            e_start(&dev, row, col);
*/
        }
          
        i++;
			}
		}

		if ( done >= CORE_N ) // some benchmarks may be lengthy ; adapt as u like
			break;
	}


	e_finalize();
  printf("That's all folks !\n");
  
	return 0;
}
