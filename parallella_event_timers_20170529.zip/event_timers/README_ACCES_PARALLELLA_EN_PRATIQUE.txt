2017/05/28


1/ branche le ventilo ou mets ta //A derriere l'UC : ventilee.
   
2/ la //A est branchee en Ethernet sur ta box ; si tu lances "Outil systeme", "Explorateur Zeroconf d'Avahi", il te donne l'adresse IP,
   en l'occurrence 192.168.0.11
   
   => tu gardes ta connection Internet tout en travaillant sur la //A :D

3/ lance deux terminaux :
   . psftp parallella@192.168.0.11 -pw parallella
   <!> Le mot de passe est le meme que pour ton UC.
   
   => te permet de COPIER DES FICHIERS
   
   . ssh parallella@192.168.011
   <!> Le mot de passe est le meme que pour ton UC.
   
   => te permet d'executer tous les pgm sur la //A

4/ src tmp dans :

  parallella@parallella:~/parallella-examples/tmp/
  
  
