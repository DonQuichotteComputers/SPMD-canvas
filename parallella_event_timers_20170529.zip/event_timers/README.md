# A canvas for writing SPMD (Single Program Multiple Data) as simple as possible -- no SDK at all.
# With configurable event timers.

## Build and Run

 Adapt the C source code to your needs ; place it in the subdirectory ./src
 Replace any batch value of "PGM" with your program name, example "main"
 
 ./build.sh
 ./run.sh [event_timer0] [event_timer1] [add_what_u_want]

 Cross compiling for an x86_64 platform ? You can use ./x86*.sh  
 Wanting to compile assembly ? You can use ./x86_buildasm.sh  
 
## Author

DonQuichotteComputers at gmail dot com
2017

## License

Don't be evil.
